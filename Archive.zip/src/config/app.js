module.exports = {
  logger: { prettyPrint: true }
}
